Selenium.prototype.doDragAndDropToObject = function(locatorStartElement, locatorEndElement) {
/** Drags an element and drops it on another element
   *
   * @param locatorStartElement an element to be dragged
   * @param locatorEndElement an element whose location (i.e., whose top left corner) will be the point where locatorStartElement  is dropped
   */
   //~ debugger;
   var startElement = this.page().findElement(locatorStartElement);
   var endElement = this.page().findElement(locatorEndElement);

   var startX = this.getElementPositionLeft(startElement);
   var startY = this.getElementPositionTop(startElement);
   var startWidth = startElement.offsetWidth;
   var startHeight = startElement.offsetHeight;
   //~ startX = startX + parseInt(startWidth / 2);
   //~ startY = startY + parseInt(startHeight / 2);
   
   var endX = this.getElementPositionLeft(endElement);
   var endY = this.getElementPositionTop(endElement);
   var destinationWidth = endElement.offsetWidth;
   var destinationHeight = endElement.offsetHeight;
   var endX = endX + parseInt(destinationWidth / 2);
   var endY = endY + parseInt(destinationHeight / 2);
   
   var deltaX = endX - startX;
   var deltaY = endY - startY;
   
   this.browserbot.triggerMouseEvent(startElement, 'mousedown', true, startX, startY);

/*   
   var movementXincrement = (deltaX > 0) ? 1 : -1;
   var movementYincrement = (deltaY > 0) ? 1 : -1;
   var clientX = startX;
   var clientY = startY;
   while ((clientX != endX) || (clientY != endY)) {
   	if (clientX != endX) {
   		clientX += movementXincrement;
        }
   	if (clientY != endY) {
   		clientY += movementYincrement;
        }
        this.browserbot.triggerMouseEvent(startElement, 'mousemove', true, clientX, clientY);
        this.browserbot.triggerMouseEvent(endElement, 'mousemove', true, clientX, clientY);//for radGrid
    }
*/
    this.browserbot.triggerMouseEvent(startElement, 'mousemove', true, endX, endY);
    this.browserbot.triggerMouseEvent(endElement, 'mousemove', true, endX, endY);
    // important event for radTreeView
 
    this.browserbot.triggerMouseEvent(startElement, 'mouseout',   true, endX, endY);
    this.browserbot.triggerMouseEvent(endElement, 'mouseover',   true, endX, endY);
    this.browserbot.triggerMouseEvent(endElement, 'mouseup',   true, endX, endY);
    this.browserbot.triggerMouseEvent(startElement, 'mouseup',   true, endX, endY);
};